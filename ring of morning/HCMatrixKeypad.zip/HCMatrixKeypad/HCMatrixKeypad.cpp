/* FILE:    HCMatrixKeypad.cpp
   DATE:    14/05/14
   VERSION: 0.1
   AUTHOR:  Andrew Davies

Library for matrix keypads.

You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.

THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY
REASON WHATSOEVER.
*/

#include "Arduino.h"
#include "HCMatrixKeypad.h"


/* Constructor for keypad type 4 x 5 (HCPROJ0003)*/
HCMatrixKeypad::HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, char Row_Marker,
								byte R1, byte R2, byte R3, byte R4, byte R5)
{
  #define ROW_5
  #define COL_4
  
  _Debounce = Debounce;
  _C1 = C1;
  _C2 = C2;
  _C3 = C3;
  _C4 = C4;
  _R1 = R1;
  _R2 = R2;
  _R3 = R3;
  _R4 = R4; 
  _R5 = R5;
  
  _Old_Key = 0;
  _Key_Pressed = FALSE;
  _KeypadState = NOTPRESSED;
  
  pinMode(C1, OUTPUT);  
  pinMode(C2, OUTPUT);  
  pinMode(C3, OUTPUT);  
  pinMode(C4, OUTPUT);  
  pinMode(R1, INPUT);
  pinMode(R2, INPUT);
  pinMode(R3, INPUT);
  pinMode(R4, INPUT);
  pinMode(R5, INPUT);
  
  digitalWrite(R1, HIGH); 
  digitalWrite(R2, HIGH); 
  digitalWrite(R3, HIGH); 
  digitalWrite(R4, HIGH); 
  digitalWrite(R5, HIGH); 
}

/* Constructor for keypad type 4 x 4 (HCPROJ0001)*/
HCMatrixKeypad::HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, char Row_Marker,
								byte R1, byte R2, byte R3, byte R4)
{
  #define ROW_4
  #define COL_4
  
  _Debounce = Debounce;
  _C1 = C1;
  _C2 = C2;
  _C3 = C3;
  _C4 = C4;
  _R1 = R1;
  _R2 = R2;
  _R3 = R3;
  _R4 = R4; 
  
  _Old_Key = 0;
  _Key_Pressed = FALSE;
  _KeypadState = NOTPRESSED;
  
  pinMode(C1, OUTPUT);  
  pinMode(C2, OUTPUT);  
  pinMode(C3, OUTPUT);  
  pinMode(C4, OUTPUT);  
  pinMode(R1, INPUT);
  pinMode(R2, INPUT);
  pinMode(R3, INPUT);
  pinMode(R4, INPUT);
  
  digitalWrite(R1, HIGH); 
  digitalWrite(R2, HIGH); 
  digitalWrite(R3, HIGH); 
  digitalWrite(R4, HIGH); 
}

/* Constructor for keypad type 3 x 4 (HCPROJ0004)*/
HCMatrixKeypad::HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, char Row_Marker,
								byte R1, byte R2, byte R3, byte R4)
{
  #define ROW_4
  #define COL_3

  _Debounce = Debounce;
  _C1 = C1;
  _C2 = C2;
  _C3 = C3;
  _R1 = R1;
  _R2 = R2;
  _R3 = R3;
  _R4 = R4; 
  
  _Old_Key = 0;
  _Key_Pressed = FALSE;
  _KeypadState = NOTPRESSED;
  
  pinMode(C1, OUTPUT);  
  pinMode(C2, OUTPUT);  
  pinMode(C3, OUTPUT);   
  pinMode(R1, INPUT);
  pinMode(R2, INPUT);
  pinMode(R3, INPUT);
  pinMode(R4, INPUT);
  
  digitalWrite(R1, HIGH); 
  digitalWrite(R2, HIGH); 
  digitalWrite(R3, HIGH); 
  digitalWrite(R4, HIGH); 
}

/* Constructor for keypad type 6 x 1 (HCPROJ0007)*/
HCMatrixKeypad::HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, byte C5, byte C6, char Row_Marker,
								byte R1)
{
  #define ROW_1
  #define COL_6

  _Debounce = Debounce;
  _C1 = C1;
  _C2 = C2;
  _C3 = C3;
  _C4 = C4;
  _C5 = C5;
  _C6 = C6;
  _R1 = R1; 
  
  _Old_Key = 0;
  _Key_Pressed = FALSE;
  _KeypadState = NOTPRESSED;
  
  pinMode(C1, OUTPUT);  
  pinMode(C2, OUTPUT);  
  pinMode(C3, OUTPUT); 
  pinMode(C4, OUTPUT);
  pinMode(C5, OUTPUT);  
  pinMode(C6, OUTPUT);    
  pinMode(R1, INPUT);
  
  digitalWrite(R1, HIGH);  
}

/* Constructor for keypad type 4 x 1 (HCPROJ0005)*/
HCMatrixKeypad::HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, char Row_Marker,
								byte R1)
{
  #define ROW_1
  #define COL_4
  
  _Debounce = Debounce;
  _C1 = C1;
  _C2 = C2;
  _C3 = C3;
  _C4 = C4;
  _R1 = R1; 
  
  _Old_Key = 0;
  _Key_Pressed = FALSE;
  _KeypadState = NOTPRESSED;
  
  pinMode(C1, OUTPUT);  
  pinMode(C2, OUTPUT);  
  pinMode(C3, OUTPUT); 
  pinMode(C4, OUTPUT);  
  pinMode(R1, INPUT);
  
  digitalWrite(R1, HIGH);  
}

/* Main state machine */
void HCMatrixKeypad::Scan(void)
{
  switch(_KeypadState)
  {
    case NOTPRESSED: /* No buttons currently pressed */
      Getkeystate();
      if(_Cur_Key != 0) _KeypadState = DEBOUNCING;
      break;
  
    case DEBOUNCING: /* Button pressed, waiting for it to settle */
      Getkeystate();
      if(_Cur_Key !=0 && (_Cur_Key == _Old_Key))
      {
        _Debounce_Counter++;
      }else
      {
        _Debounce_Counter = 0;
      }
      
      if(_Debounce_Counter == _Debounce)  
      {
        _KeypadState = NEWKEY;
        _Debounce_Counter = 0;
      }
      break;
      
      
     case NEWKEY: /* Button currently pressed, nothing to do other 
	                 than wait for user to read the key */
       break;
       
     case KEYREAD: /* Last key press has already been read */
         Getkeystate(); /* Scan the keypad until button is released */
         if(_Cur_Key == 0) _KeypadState = NOTPRESSED;    
       break;
  }
  _Old_Key = _Cur_Key;
}

/* Check if a new key has been pressed */
boolean HCMatrixKeypad::New_Key(void)
{
  if (_KeypadState == NEWKEY)
  {
    _KeypadState = KEYREAD;
    return TRUE; 
  }else
  {
    return FALSE;
  }
}

/* Makes one complete scan of the keypad. */
void HCMatrixKeypad::Getkeystate(void)
{
  _Cur_Key = 0;
  digitalWrite(_C1, LOW); 
#if defined(COL_2) || defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C2, HIGH); 
#endif 
#if defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C3, HIGH); 
#endif 
#if defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C4, HIGH);  
#endif 
#if defined(COL_5) || defined(COL_6)
  digitalWrite(_C5, HIGH); 
#endif   
#if defined(COL_6) 
  digitalWrite(_C6, HIGH);  
#endif 

  if (!digitalRead(_R1)) _Cur_Key = 11;
#if defined(ROW_2) || defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R2)) _Cur_Key = 21;
#endif
#if defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R3)) _Cur_Key = 31;
#endif
#if defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R4)) _Cur_Key = 41;
#endif
#if defined(ROW_5)
  if (!digitalRead(_R5)) _Cur_Key = 51;  
#endif

  digitalWrite(_C1, HIGH); 
#if defined(COL_2) || defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C2, LOW); 
#endif 
#if defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C3, HIGH); 
#endif 
#if defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C4, HIGH);  
#endif 
#if defined(COL_5) || defined(COL_6)
  digitalWrite(_C5, HIGH); 
#endif   
#if defined(COL_6) 
  digitalWrite(_C6, HIGH);  
#endif 
  
  if (!digitalRead(_R1)) _Cur_Key = 12;
#if defined(ROW_2) || defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R2)) _Cur_Key = 22;
#endif
#if defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R3)) _Cur_Key = 32;
#endif
#if defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R4)) _Cur_Key = 42;
#endif
#if defined(ROW_5)
  if (!digitalRead(_R5)) _Cur_Key = 52;
#endif  

  
  digitalWrite(_C1, HIGH); 
#if defined(COL_2) || defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C2, HIGH); 
#endif 
#if defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C3, LOW); 
#endif 
#if defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C4, HIGH);  
#endif 
#if defined(COL_5) || defined(COL_6)
  digitalWrite(_C5, HIGH); 
#endif   
#if defined(COL_6) 
  digitalWrite(_C6, HIGH);  
#endif 
 
  if (!digitalRead(_R1)) _Cur_Key = 13;
#if defined(ROW_2) || defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R2)) _Cur_Key = 23;
#endif
#if defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R3)) _Cur_Key = 33;
#endif
#if defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R4)) _Cur_Key = 43;
#endif
#if defined(ROW_5)
  if (!digitalRead(_R5)) _Cur_Key = 53;
#endif


  digitalWrite(_C1, HIGH); 
#if defined(COL_2) || defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C2, HIGH); 
#endif 
#if defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C3, HIGH); 
#endif 
#if defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C4, LOW);  
#endif 
#if defined(COL_5) || defined(COL_6)
  digitalWrite(_C5, HIGH); 
#endif   
#if defined(COL_6) 
  digitalWrite(_C6, HIGH);  
#endif 
  
  if (!digitalRead(_R1)) _Cur_Key = 14;
#if defined(ROW_2) || defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R2)) _Cur_Key = 24;
#endif
#if defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R3)) _Cur_Key = 34;
#endif
#if defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R4)) _Cur_Key = 44;
#endif
#if defined(ROW_5)
  if (!digitalRead(_R5)) _Cur_Key = 54;
#endif


  digitalWrite(_C1, HIGH); 
#if defined(COL_2) || defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C2, HIGH); 
#endif 
#if defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C3, HIGH); 
#endif 
#if defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C4, HIGH);  
#endif 
#if defined(COL_5) || defined(COL_6)
  digitalWrite(_C5, LOW); 
#endif   
#if defined(COL_6) 
  digitalWrite(_C6, HIGH);  
#endif 
  
  if (!digitalRead(_R1)) _Cur_Key = 15;
#if defined(ROW_2) || defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R2)) _Cur_Key = 25;
#endif
#if defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R3)) _Cur_Key = 35;
#endif
#if defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R4)) _Cur_Key = 45;
#endif
#if defined(ROW_5)
  if (!digitalRead(_R5)) _Cur_Key = 55;
#endif

  digitalWrite(_C1, HIGH); 
#if defined(COL_2) || defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C2, HIGH); 
#endif 
#if defined(COL_3) || defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C3, HIGH); 
#endif 
#if defined(COL_4) || defined(COL_5) || defined(COL_6)
  digitalWrite(_C4, HIGH);  
#endif 
#if defined(COL_5) || defined(COL_6)
  digitalWrite(_C5, HIGH); 
#endif   
#if defined(COL_6) 
  digitalWrite(_C6, LOW);  
#endif 
 
  if (!digitalRead(_R1)) _Cur_Key = 16;
#if defined(ROW_2) || defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R2)) _Cur_Key = 26;
#endif
#if defined(ROW_3) || defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R3)) _Cur_Key = 36;
#endif
#if defined(ROW_4) || defined(ROW_5)
  if (!digitalRead(_R4)) _Cur_Key = 46;
#endif
#if defined(ROW_5)
  if (!digitalRead(_R5)) _Cur_Key = 56;
#endif
}

/* Returns the last key read as a decimal byte. The 10's column represents 
   the column number pressed, and the 1's column represents the row number 
   pressed.  */
byte HCMatrixKeypad::Read(void)
{
  return _Cur_Key;
}