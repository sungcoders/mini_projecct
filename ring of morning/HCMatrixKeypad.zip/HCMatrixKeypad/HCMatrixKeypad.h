/* FILE:    HCMatrixKeypad.h
   DATE:    14/05/14
   VERSION: 0.1
   AUTHOR:  Andrew Davies

Library header for matrix keypads.

You may copy, alter and reuse this code in any way you like, but please leave
reference to HobbyComponents.com in your comments if you redistribute this code.
This software may not be used directly for the purpose of selling products that
directly compete with Hobby Components Ltd's own range of products.

THIS SOFTWARE IS PROVIDED "AS IS". HOBBY COMPONENTS MAKES NO WARRANTIES, WHETHER
EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, ACCURACY OR LACK OF NEGLIGENCE.
HOBBY COMPONENTS SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR ANY DAMAGES,
INCLUDING, BUT NOT LIMITED TO, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY
REASON WHATSOEVER.
*/

#ifndef HCMatrixKeypad_h
#define HCMatrixKeypad_h

#include "Arduino.h"

#define TRUE (1==1)
#define FALSE (!TRUE)
#define ROWMARKER '#'

/* Keypad state machine states */
enum HCkeypadState 
{
  NOTPRESSED, /* No buttons currently pressed */
  DEBOUNCING, /* Button pressed, waiting for it to settle */
  NEWKEY, /* Button currently pressed */
  KEYREAD  /* Last key press has already been read */
 };
 
 
class HCMatrixKeypad
{
  public:
  /* Keypad is 4 x 5 (HCPROJ0003)*/
  HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, char Row_Marker,
				 byte R1, byte R2, byte R3, byte R4, byte R5);
	
  /* Keypad is 4 x 4 (HCPROJ0001)*/	
  HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, char Row_Marker,
				 byte R1, byte R2, byte R3, byte R4);
				 
  /* Keypad is 3 x 4 (HCPROJ0004)*/
  HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, char Row_Marker,
				 byte R1, byte R2, byte R3, byte R4);

  /* Keypad is 6 x 1 (HCPROJ0007)*/
  HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, byte C5, byte C6, char Row_Marker,
				 byte R1);

  /* Keypad is 4 x 1 (HCPROJ0005)*/
  HCMatrixKeypad(byte Debounce, byte C1, byte C2, byte C3, byte C4, char Row_Marker,
				 byte R1);
				 
  /* Main state machine which also triggers a scan of the keypad if necessary. Must be constantly run */
  void Scan(void);
  /*Return TRUE if a new key has been pressed */
  boolean New_Key(void);
  /* Contains the last key read */
  byte Read(void);
  
  private:
  byte _Old_Key;
  byte _Cur_Key;
  byte _Debounce_Counter;
  boolean _Key_Pressed;

  byte _Debounce;
  byte _C1;
  byte _C2;
  byte _C3;
  byte _C4;
  byte _C5;
  byte _C6;
  byte _R1;
  byte _R2;
  byte _R3;
  byte _R4; 
  byte _R5;
  
  HCkeypadState _KeypadState;
  
  /* Makes one scan of the keypad */
  void Getkeystate(void);
};
#endif